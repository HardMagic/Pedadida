<?php
/**********************************************************************************
* PortalShoutbox.php                                                              *
***********************************************************************************
* SimplePortal                                                                    *
* SMF Modification Project Founded by [SiNaN] (sinan@simplemachines.org)          *
* =============================================================================== *
* Software Version:           SimplePortal 2.3.5                                  *
* Software by:                SimplePortal Team (http://www.simpleportal.net)     *
* Copyright 2008-2009 by:     SimplePortal Team (http://www.simpleportal.net)     *
* Support, News, Updates at:  http://www.simpleportal.net                         *
***********************************************************************************
* This program is free software; you may redistribute it and/or modify it under   *
* the terms of the provided license as published by Simple Machines LLC.          *
*                                                                                 *
* This program is distributed in the hope that it is and will be useful, but      *
* WITHOUT ANY WARRANTIES; without even any implied warranty of MERCHANTABILITY    *
* or FITNESS FOR A PARTICULAR PURPOSE.                                            *
*                                                                                 *
* See the "license.txt" file for details of the Simple Machines license.          *
* The latest version can always be found at http://www.simplemachines.org.        *
**********************************************************************************/

if (!defined('SMF'))
	die('Hacking attempt...');

/*
	void sportal_shoutbox()
		// !!!
*/

function sportal_shoutbox()
{
	global $db_prefix, $context, $scripturl, $txt, $sourcedir, $func, $user_info;

	$shoutbox_id = !empty($_REQUEST['shoutbox_id']) ? (int) $_REQUEST['shoutbox_id'] : 0;
	$request_time = !empty($_REQUEST['time']) ? (int) $_REQUEST['time'] : 0;

	$context['SPortal']['shoutbox'] = sportal_get_shoutbox($shoutbox_id, true, true);

	if (empty($context['SPortal']['shoutbox']))
		fatal_lang_error('error_sp_shoutbox_not_exist', false);

	$context['SPortal']['shoutbox']['warning'] = parse_bbc($context['SPortal']['shoutbox']['warning']);

	$can_moderate = allowedTo('sp_admin') || allowedTo('sp_manage_shoutbox');
	if (!$can_moderate && !empty($context['SPortal']['shoutbox']['moderator_groups']))
		$can_moderate = count(array_intersect($user_info['groups'], $context['SPortal']['shoutbox']['moderator_groups'])) > 0;

	if (!empty($_REQUEST['shout']))
	{
		checkSession('request');

		is_not_guest();

		if (!($flood = sp_prevent_flood('spsbp', false)))
		{
			require_once($sourcedir . '/Subs-Post.php');

			$_REQUEST['shout'] = trim(addslashes($func['htmlspecialchars'](stripslashes($_REQUEST['shout']), ENT_QUOTES)));
			preparsecode($_REQUEST['shout']);

			if (!empty($_REQUEST['shout']))
				sportal_create_shout($context['SPortal']['shoutbox'], $_REQUEST['shout']);
		}
		else
			$context['SPortal']['shoutbox']['warning'] = $flood;
	}

	if (!empty($_REQUEST['delete']))
	{
		checkSession('request');

		if (!$can_moderate)
			fatal_lang_error('error_sp_cannot_shoutbox_moderate', false);

		$_REQUEST['delete'] = (int) $_REQUEST['delete'];

		if (!empty($_REQUEST['delete']))
			sportal_delete_shout($shoutbox_id, $_REQUEST['delete']);
	}

	loadTemplate('PortalShoutbox');

	if (isset($_REQUEST['xml']))
	{
		$shout_parameters = array(
			'limit' => $context['SPortal']['shoutbox']['num_show'],
			'bbc' => $context['SPortal']['shoutbox']['allowed_bbc'],
			'reverse' => $context['SPortal']['shoutbox']['reverse'],
			'cache' => $context['SPortal']['shoutbox']['caching'],
			'can_moderate' => $can_moderate,
		);
		$context['SPortal']['shouts'] = sportal_get_shouts($shoutbox_id, $shout_parameters);

		$context['sub_template'] = 'shoutbox_xml';
		$context['SPortal']['updated'] = empty($context['SPortal']['shoutbox']['last_update']) || $context['SPortal']['shoutbox']['last_update'] > $request_time;

		return;
	}

	$request = db_query("
		SELECT COUNT(*)
		FROM {$db_prefix}sp_shouts
		WHERE ID_SHOUTBOX = $shoutbox_id", __FILE__, __LINE__);
	list ($total_shouts) =  mysql_fetch_row($request);
	mysql_free_result($request);

	$context['per_page'] = $context['SPortal']['shoutbox']['num_show'];
	$context['start'] = !empty($_REQUEST['start']) ? (int) $_REQUEST['start'] : 0;
	$context['page_index'] = constructPageIndex($scripturl . '?action=portal;sa=shoutbox;shoutbox_id=' . $shoutbox_id, $context['start'], $total_shouts, $context['per_page']);

	$shout_parameters = array(
		'start' => $context['start'],
		'limit' => $context['per_page'],
		'bbc' => $context['SPortal']['shoutbox']['allowed_bbc'],
		'cache' => $context['SPortal']['shoutbox']['caching'],
		'can_moderate' => $can_moderate,
	);
	$context['SPortal']['shouts_history'] = sportal_get_shouts($shoutbox_id, $shout_parameters);

	$context['SPortal']['shoutbox_id'] = $shoutbox_id;
	$context['sub_template'] = 'shoutbox_all';
	$context['page_title'] = $context['SPortal']['shoutbox']['name'];
}

?>